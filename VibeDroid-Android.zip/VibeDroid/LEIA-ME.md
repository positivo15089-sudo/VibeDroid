# VibeDroid — criador de aplicativos Android por conversa

Projeto-fonte Android em Java, interface em português. Esta primeira versão cria aplicativos **HTML/CSS/JavaScript encapsulados em um aplicativo Android WebView**. Não gera telas Kotlin nativas nem compila APK dentro do celular.

## O que está implementado

- Criar e reabrir vários projetos salvos no armazenamento privado do app.
- Gerar um aplicativo com Gemini e pedir alterações usando o código atual como contexto.
- Histórico de conversa, editor de código e restauração das últimas 10 versões.
- Prévia interativa com JavaScript e dados locais separados por projeto.
- Exemplo offline de tarefas: adicionar, concluir, excluir e salvar tarefas.
- Exportar ZIP com projeto Android independente, nome e identificador próprios.
- Fluxo manual do GitHub Actions para compilar o criador e os projetos exportados.
- Mensagens de erro para falhas de rede, chave, modelo, cota e respostas incompletas.

## Como obter o APK do VibeDroid pelo GitHub

1. Extraia este ZIP.
2. Crie um repositório seu no GitHub e envie **o conteúdo da pasta VibeDroid para a raiz**, incluindo `.github/workflows/apk.yml`.
3. Na aba **Actions**, habilite os fluxos se necessário. Abra **Compilar APK** e escolha **Run workflow**.
4. Quando o fluxo terminar com sucesso, baixe o artefato **aplicativo-android** e extraia o APK.
5. Transfira o APK ao Android e autorize a instalação pelo aplicativo usado para abrir esse arquivo.

O fluxo precisa de internet para obter o SDK e as dependências. Pode consumir a cota do GitHub Actions. Não foi executado a partir deste ambiente. O APK de depuração serve para testes; distribuição exige assinatura de lançamento. Execuções em máquinas limpas podem produzir chaves de depuração diferentes: atualizações de APK podem exigir reinstalação, que apaga os dados locais. Preserve projetos importantes exportando-os.

## Compilar no computador

Requer **JDK 17, Gradle 8.9, Android SDK 35 e Build Tools 34.0.0**. O plugin Android está fixado em 8.7.3. Android mínimo: 8.0 (API 26). Target 34 nesta versão de teste; não é uma entrega preparada para publicação na Play Store.

1. Instale os pré-requisitos e configure `ANDROID_HOME` para seu SDK, ou `sdk.dir` em `local.properties`.
2. Dentro da pasta do projeto, execute:

```sh
gradle wrapper --gradle-version 8.9
gradle assembleDebug lintDebug
```

3. O APK estará em `app/build/outputs/apk/debug/app-debug.apk`.

O wrapper binário não está incluído. Depois do comando `gradle wrapper`, o projeto também pode ser aberto e sincronizado no Android Studio.

## Usar o criador

1. Abra **Experimentar exemplo offline** para testar sem IA.
2. Para criar com IA, abra **Configurar IA**, informe sua chave Gemini e o ID exato de um modelo da sua conta que aceite saída JSON estruturada. Obtenha os dados no [Google AI Studio](https://aistudio.google.com/).
3. A chave fica somente em memória, não é incluída no ZIP e deve ser informada novamente após o encerramento do processo. O nome do modelo fica salvo. A geração envia o pedido e todo o código atual ao Google e pode consumir cota ou gerar cobrança.
4. Abra **Criar aplicativo**, dê um nome e descreva a ideia. Exemplo: “Crie um controle de vendas offline com cadastro de produtos, carrinho, total em reais e histórico de vendas salvo localmente”.
5. Toque em **Gerar / aplicar alteração**. Mantenha o app aberto. Depois use **Testar aplicativo**.
6. Peça alterações, por exemplo: “Adicione busca de produtos e modo escuro”. O código atual acompanha cada pedido; mensagens anteriores ficam disponíveis visualmente no histórico.
7. Use **Exportar projeto Android (.zip)**. Extraia esse novo ZIP e repita a compilação no computador ou GitHub para instalar o aplicativo criado.

## Limites desta versão

- Criação por IA exige internet, chave própria e modelo compatível. Qualidade e correção do código gerado variam; revise e teste antes de usar dados reais.
- Os apps gerados são offline: rede, bibliotecas externas, iframes, formulários para servidores e acesso a arquivos ficam bloqueados na prévia e no aplicativo exportado. Não há login real em servidor, pagamento, câmera, GPS, notificações, backend ou loja de apps.
- Prévia e aplicativos gerados usam WebView sem ponte JavaScript/nativa. HTML gerado não ganha acesso à chave ou aos arquivos do criador. A prévia usa uma origem diferente para cada projeto.
- O ZIP contém código, não APK nem os dados preenchidos na prévia. A versão exportada começa com armazenamento vazio. Não há importação de ZIP nesta versão.
- Histórico de versões restaura código, não reverte dados que o próprio app gerado tenha alterado no localStorage.
- Não há geração em segundo plano garantida, streaming ou cancelamento. Se o Android encerrar o processo, o código salvo permanece; o pedido em andamento pode se perder.
- Para oferecer o criador como serviço público, é necessário implementar backend, autenticação, gestão de uso e cobrança. Nunca embuta uma chave compartilhada no APK.

## Validação realizada nesta entrega

Foram verificados a estrutura e os manifestos XML, a substituição dos dados do modelo de exportação e a sintaxe JavaScript do exemplo. O teste interativo não pôde executar porque o navegador de testes não está instalado. O ambiente não dispõe de Android SDK/Gradle: não foi possível compilar, executar Android Lint, instalar em dispositivo ou validar uma chamada Gemini com credenciais reais. O código-fonte é uma versão inicial, não um APK já testado.

## Referências técnicas

- [Compatibilidade do Android Gradle Plugin 8.7](https://developer.android.com/build/releases/agp-8-7-0-release-notes)
- [API Gemini generateContent](https://ai.google.dev/api/generate-content)
- [Cuidados com pontes nativas em WebView](https://developer.android.com/privacy-and-security/risks/insecure-webview-native-bridges)
