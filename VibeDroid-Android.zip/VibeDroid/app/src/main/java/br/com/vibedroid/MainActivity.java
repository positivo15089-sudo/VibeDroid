package br.com.vibedroid;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import android.util.AtomicFile;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.*;

public class MainActivity extends Activity {
 private LinearLayout root,body;
 private EditText prompt;
 private JSONObject project;
 private String key="",model="",pendingExport;
 private boolean busy=false;
 private final ExecutorService executor=Executors.newSingleThreadExecutor();
 private static final int BG=0xff101222, CARD=0xff202338, TEXT=0xfff4f3ff, ACCENT=0xffb8ff78;
 @Override public void onCreate(Bundle b){super.onCreate(b);model=getPreferences(0).getString("model","");if(b!=null)pendingExport=b.getString("export");home();}
 @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putString("export",pendingExport);}
 private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
 private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
 private void screen(String title,String subtitle){
  root=column();root.setPadding(dp(20),dp(18),dp(20),dp(12));root.setBackgroundColor(BG);setContentView(root);
  label(root,title,28,TEXT);label(root,subtitle,14,0xffb5b8cf);
  ScrollView scroll=new ScrollView(this);body=column();body.setPadding(0,dp(16),0,0);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
 }
 private TextView label(LinearLayout parent,String text,int size,int color){TextView t=new TextView(this);t.setText(text);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,dp(6),0,dp(8));parent.addView(t);return t;}
 private void button(LinearLayout parent,String title,Runnable action){Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextColor(BG);GradientDrawable d=new GradientDrawable();d.setColor(ACCENT);d.setCornerRadius(dp(12));b.setBackground(d);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(50));p.setMargins(0,dp(7),0,dp(7));parent.addView(b,p);b.setOnClickListener(v->{if(!busy)action.run();else toast("Aguarde a geração terminar.");});}
 private EditText input(LinearLayout parent,String hint,String value){EditText e=new EditText(this);e.setTextColor(TEXT);e.setHintTextColor(0xff989ebd);e.setText(value);e.setHint(hint);e.setTextSize(16);parent.addView(e,new LinearLayout.LayoutParams(-1,-2));return e;}
 private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
 private void error(Exception e){toast(e.getMessage()==null?"Não foi possível concluir.":e.getMessage());}
 private void home(){
  project=null;
  screen("VibeDroid ✦","Transforme uma ideia em aplicativo.");
  label(body,"O que você quer criar?",22,TEXT);
  label(body,"Descreva, teste e melhore pelo chat. Crie apps offline com dados locais.",16,0xffb5b8cf);
  button(body,"+ Criar aplicativo",()->newName(false));button(body,"Experimentar exemplo offline",()->newName(true));button(body,"Configurar IA",this::settings);
  label(body,"Seus projetos",21,TEXT);
  File[] files=getFilesDir().listFiles((d,n)->n.endsWith(".json"));
  if(files==null||files.length==0)label(body,"Seus aplicativos aparecerão aqui.",15,0xffb5b8cf);
  else {Arrays.sort(files,(a,b)->Long.compare(b.lastModified(),a.lastModified()));for(File f:files){try{JSONObject p=new JSONObject(PreviewActivity.read(new FileInputStream(f)));button(body,p.getString("name"),()->{project=p;editor();});}catch(Exception e){label(body,"Não foi possível ler "+f.getName(),14,0xffffa080);}}}
  label(body,"IA: chave própria • Exportação: projeto Android ZIP",12,0xffb5b8cf);
 }
 private void newName(boolean demo){
  EditText name=new EditText(this);name.setHint("Nome do aplicativo");
  new AlertDialog.Builder(this).setTitle("Novo projeto").setView(name).setNegativeButton("Cancelar",null).setPositiveButton("Criar",(d,w)->{
   try{String n=name.getText().toString().trim();if(n.isEmpty())n=demo?"Minhas tarefas":"Meu aplicativo";if(n.length()>60)throw new IOException("Use até 60 caracteres no nome.");
    project=new JSONObject().put("id",UUID.randomUUID().toString()).put("name",n).put("html",demo?PreviewActivity.read(getAssets().open("demo.html")):"").put("history",new JSONArray()).put("versions",new JSONArray());save(project);editor();
   }catch(Exception e){error(e);}
  }).show();
 }
 private void settings(){
  LinearLayout fields=column();fields.setPadding(dp(20),0,dp(20),0);
  label(fields,"O pedido e o código atual serão enviados ao Google Gemini. A chave fica apenas na memória desta sessão. O uso pode consumir sua cota ou gerar cobrança.",15,TEXT);
  EditText k=input(fields,"Sua chave da API Gemini",key);k.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
  EditText m=input(fields,"ID de um modelo disponível na sua conta",model);m.setSingleLine(true);
  new AlertDialog.Builder(this).setTitle("Conectar IA").setView(fields).setNegativeButton("Cancelar",null).setPositiveButton("Usar nesta sessão",(d,w)->{key=k.getText().toString().trim();model=m.getText().toString().trim();getPreferences(0).edit().putString("model",model).apply();toast("Configuração atualizada.");}).show();
 }
 private void editor(){
  screen(project.optString("name"),"ESTÚDIO • Crie e refine conversando");
  button(body,"← Meus projetos",this::home);
  JSONArray h=project.optJSONArray("history");if(h!=null)for(int i=0;i<h.length();i++){JSONObject msg=h.optJSONObject(i);if(msg!=null)label(body,("user".equals(msg.optString("role"))?"Você: ":"VibeDroid: ")+msg.optString("text"),15,TEXT);}
  prompt=input(body,"Ex.: Crie um controle de vendas com cadastro de produtos","");prompt.setMinLines(3);prompt.setGravity(Gravity.TOP);prompt.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
  button(body,"✦ Gerar / aplicar alteração",this::generate);
  if(!project.optString("html").isEmpty()){
   button(body,"▶ Testar aplicativo",()->startActivity(new Intent(this,PreviewActivity.class).putExtra("id",project.optString("id"))));
   button(body,"Ver e editar código",this::code);button(body,"Histórico de versões",this::versions);button(body,"Exportar projeto Android (.zip)",this::export);
  }
  button(body,"Configurar IA",this::settings);
 }
 private void save(JSONObject p)throws Exception{
  AtomicFile f=new AtomicFile(new File(getFilesDir(),p.getString("id")+".json"));FileOutputStream out=null;
  try{out=f.startWrite();out.write(p.toString().getBytes(StandardCharsets.UTF_8));f.finishWrite(out);}catch(Exception e){if(out!=null)f.failWrite(out);throw e;}
 }
 private JSONObject updated(String html,String request,String summary)throws Exception{
  JSONObject p=new JSONObject(project.toString());JSONArray v=p.getJSONArray("versions");
  if(!p.getString("html").isEmpty())v.put(new JSONObject().put("html",p.getString("html")).put("date",new java.text.SimpleDateFormat("dd/MM HH:mm",Locale.getDefault()).format(new Date())));
  while(v.length()>10)v.remove(0);p.put("html",html);
  JSONArray h=p.getJSONArray("history");h.put(new JSONObject().put("role","user").put("text",request));h.put(new JSONObject().put("role","model").put("text",summary));while(h.length()>30)h.remove(0);
  return p;
 }
 private void code(){
  screen("Código do aplicativo","HTML, CSS e JavaScript em um arquivo");EditText source=input(body,"HTML",project.optString("html"));source.setTypeface(Typeface.MONOSPACE);source.setTextSize(12);source.setGravity(Gravity.TOP);source.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
  button(body,"Salvar código",()->{try{String html=source.getText().toString();validate(html);JSONObject next=updated(html,"Edição manual","Código salvo.");save(next);project=next;editor();}catch(Exception e){error(e);}});button(body,"Voltar sem salvar",this::editor);
 }
 private void versions(){
  JSONArray versions=project.optJSONArray("versions");if(versions.length()==0){toast("Nenhuma versão anterior.");return;}
  String[] names=new String[versions.length()];for(int i=0;i<names.length;i++)names[i]="Versão "+(i+1)+" • "+versions.optJSONObject(i).optString("date");
  new AlertDialog.Builder(this).setTitle("Restaurar versão").setItems(names,(d,index)->{try{JSONObject next=updated(versions.getJSONObject(index).getString("html"),"Restaurar versão "+(index+1),"Versão restaurada.");save(next);project=next;editor();}catch(Exception e){error(e);}}).setNegativeButton("Cancelar",null).show();
 }
 private void validate(String html)throws IOException{String s=html.toLowerCase(Locale.ROOT);if(html.length()>500000||!s.contains("<html")||!s.contains("</html>"))throw new IOException("HTML incompleto ou maior que 500 mil caracteres. Peça uma versão menor.");}
 private void generate(){
  String request=prompt.getText().toString().trim();if(request.isEmpty()){toast("Descreva o aplicativo ou a alteração.");return;}
  if(key.isEmpty()||!model.matches("[a-zA-Z0-9._-]+")){settings();return;}
  if(request.length()>12000){toast("Use um pedido de até 12 mil caracteres.");return;}
  String current=project.optString("html"),apiKey=key,selectedModel=model;busy=true;
  label(body,"Gerando… Pode levar até 2 minutos. Mantenha o app aberto.",16,ACCENT);
  executor.execute(()->{
   try{
    JSONObject result=callGemini(apiKey,selectedModel,current,request);
    String html=result.getString("html"),summary=result.optString("summary","Aplicativo atualizado.");validate(html);
    runOnUiThread(()->{if(isDestroyed())return;busy=false;try{JSONObject next=updated(html,request,summary);save(next);project=next;editor();}catch(Exception e){error(e);}});
   }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;busy=false;error(e);editor();prompt.setText(request);});}
  });
 }
 private JSONObject callGemini(String k,String m,String current,String request)throws Exception{
  String system="Você é o VibeDroid, criador de aplicativos Android offline em WebView. Retorne somente JSON com html e summary. html deve ser um documento HTML completo com CSS e JS inline, em português-BR, mobile-first, bonito e funcional. Use apenas recursos locais; não há rede, bibliotecas externas, eval, iframes ou APIs nativas. Use localStorage para dados. Não invente integrações ou funções que não podem funcionar offline. Use DOM seguro para entradas. Preserve dados e funções existentes ao editar. summary deve explicar o resultado e limitações. Não inclua cercas markdown.";
  JSONObject schema=new JSONObject("{\"type\":\"OBJECT\",\"properties\":{\"html\":{\"type\":\"STRING\"},\"summary\":{\"type\":\"STRING\"}},\"required\":[\"html\",\"summary\"]}");
  JSONObject payload=new JSONObject().put("systemInstruction",new JSONObject().put("parts",new JSONArray().put(new JSONObject().put("text",system))))
   .put("contents",new JSONArray().put(new JSONObject().put("role","user").put("parts",new JSONArray().put(new JSONObject().put("text","Código atual:\n"+current+"\nPedido:\n"+request)))))
   .put("generationConfig",new JSONObject().put("responseMimeType","application/json").put("responseSchema",schema));
  HttpURLConnection c=(HttpURLConnection)new URL("https://generativelanguage.googleapis.com/v1beta/models/"+m+":generateContent").openConnection();
  try{c.setRequestMethod("POST");c.setConnectTimeout(20000);c.setReadTimeout(120000);c.setInstanceFollowRedirects(false);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("x-goog-api-key",k);
   try(OutputStream out=c.getOutputStream()){out.write(payload.toString().getBytes(StandardCharsets.UTF_8));}
   int status=c.getResponseCode();if(status!=200)throw new IOException(status==429?"Cota ou limite da IA atingido. Tente depois.":status==400?"Pedido ou modelo incompatível. Confira o ID do modelo e suporte a JSON.":status==401||status==403?"Chave sem autorização. Confira sua chave e conta.":status==404?"Modelo não encontrado. Confira o ID em Configurar IA.":"Falha da IA (HTTP "+status+"). Tente novamente.");
   JSONObject response=new JSONObject(PreviewActivity.read(c.getInputStream()));JSONArray candidates=response.optJSONArray("candidates");if(candidates==null||candidates.length()==0)throw new IOException("A IA não retornou conteúdo para esse pedido.");
   JSONObject candidate=candidates.getJSONObject(0);if(!"STOP".equals(candidate.optString("finishReason")))throw new IOException("Geração incompleta. Peça um aplicativo menor ou tente novamente.");
   JSONArray parts=candidate.getJSONObject("content").getJSONArray("parts");StringBuilder text=new StringBuilder();for(int i=0;i<parts.length();i++){JSONObject part=parts.getJSONObject(i);if(!part.optBoolean("thought",false))text.append(part.optString("text",""));}
   return new JSONObject(text.toString());
  }finally{c.disconnect();}
 }
 private void export(){
  try{File f=new File(getCacheDir(),"export.json");try(FileOutputStream out=new FileOutputStream(f)){out.write(project.toString().getBytes(StandardCharsets.UTF_8));}pendingExport=f.getAbsolutePath();}catch(Exception e){error(e);return;}Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/zip").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"App-"+project.optString("id").substring(0,8)+".zip");startActivityForResult(i,42);
 }
 private String xml(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;").replace("@","&#64;").replace("?","&#63;");}
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=42)return;
  if(result!=RESULT_OK||data==null||data.getData()==null){pendingExport=null;return;}
  if(pendingExport==null){toast("Exporte novamente o projeto.");return;}
  try{JSONObject p=new JSONObject(PreviewActivity.read(new FileInputStream(pendingExport)));JSONObject template=new JSONObject(PreviewActivity.read(getAssets().open("template.json")));String id=p.getString("id").replace("-","");
   OutputStream output=getContentResolver().openOutputStream(data.getData());if(output==null)throw new IOException("Não foi possível abrir o destino.");
   try(ZipOutputStream zip=new ZipOutputStream(output)){
    Iterator<String> keys=template.keys();while(keys.hasNext()){String path=keys.next();zip.putNextEntry(new ZipEntry(path.replace("__ID__",id)));zip.write(template.getString(path).replace("__ID__",id).replace("__TITLE__",xml(p.getString("name"))).getBytes(StandardCharsets.UTF_8));zip.closeEntry();}
    zip.putNextEntry(new ZipEntry("app/src/main/assets/index.html"));zip.write(p.getString("html").getBytes(StandardCharsets.UTF_8));zip.closeEntry();
   }toast("Projeto ZIP salvo. Compile para obter o APK.");
  }catch(Exception e){error(e);}finally{pendingExport=null;}
 }
 @Override public void onBackPressed(){if(busy){toast("Aguarde a geração terminar.");return;}if(project==null)super.onBackPressed();else home();}
 @Override protected void onDestroy(){executor.shutdownNow();key="";super.onDestroy();}
}
