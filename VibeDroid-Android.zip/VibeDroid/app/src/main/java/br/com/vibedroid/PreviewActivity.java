package br.com.vibedroid;
import android.app.*;
import android.os.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
public class PreviewActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  try {
   String id=getIntent().getStringExtra("id");
   String html;
   if(id==null) { id="app"; try(InputStream in=getAssets().open("index.html")){ html=read(in); } }
   else { if(!id.matches("[a-zA-Z0-9-]+")) throw new IOException("Projeto inválido"); html=new org.json.JSONObject(read(new FileInputStream(new File(getFilesDir(),id+".json")))).getString("html"); }
   final byte[] page=html.getBytes(StandardCharsets.UTF_8);
   final String origin="https://p-"+id+".invalid/";
   LinearLayout layout=new LinearLayout(this);layout.setOrientation(1);
   Button close=new Button(this);close.setText("Voltar");close.setOnClickListener(v->finish());layout.addView(close);
   web=new WebView(this);layout.addView(web,new LinearLayout.LayoutParams(-1,0,1));setContentView(layout);
   web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
   web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);
   web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
   web.setWebChromeClient(new WebChromeClient());
   web.setWebViewClient(new WebViewClient(){
    @Override public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){return !r.getUrl().toString().startsWith(origin+"#");}
    @Override public WebResourceResponse shouldInterceptRequest(WebView w,WebResourceRequest r){
     if(r.isForMainFrame() && r.getUrl().toString().equals(origin)){
      Map<String,String> h=new HashMap<>();
      h.put("Content-Security-Policy","default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; font-src data:; connect-src 'none'; frame-src 'none'; worker-src 'none'; form-action 'none'; base-uri 'none'");
      return new WebResourceResponse("text/html","UTF-8",200,"OK",h,new ByteArrayInputStream(page));
     }
     return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
    }
   });web.loadUrl(origin);
  }catch(Exception e){TextView t=new TextView(this);t.setText("Não foi possível abrir a prévia.");setContentView(t);}
 }
 static String read(InputStream in)throws IOException {try(InputStream s=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=s.read(b))!=-1){out.write(b,0,n);if(out.size()>32000000)throw new IOException("Arquivo muito grande");}return out.toString("UTF-8");}}
 @Override protected void onDestroy(){if(web!=null){web.stopLoading();web.destroy();}super.onDestroy();}
}
